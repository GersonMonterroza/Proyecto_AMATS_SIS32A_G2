<?php
    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }
    $id=$_GET["id"];
    $conexion->query("DELETE FROM PRODUCTOS WHERE ID_PRODUCTO=$id");
    #$conexion->query("DELETE FROM COLORPRODUCT WHERE ID_PRODUCTO=$id");
    $conexion->query("DELETE FROM TALLAPRODUCT WHERE ID_PRODUCTO=$id");
    echo '<meta http-equiv="Refresh" content="0; URL=index.php?pag=model/agre_product.php">';
?>