<?php
    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }
    if(isset($_POST["agregarpromo"])){
        $titulo=$_POST["nombre"];
        $descrip=$_POST["descrip"];
        $unidades=$_POST["canti"];
        $precio=$_POST["precio"];

        //DATOS DE LA IMAGEN
        $nom_img=$_FILES["image"]["name"];
        $tipo_img=$_FILES["image"]["type"];
        $tamaño_img=$_FILES["image"]["size"];

        if($tamaño_img<=5000000){//VALIDAR EL TAMAÑO DE LA IMAGEN
            if($tipo_img=="image/jpeg" || $tipo_img=="image/jpg" || $tipo_img=="image/png"){//VALIDAR EL TIPO DE IMAGEN
                $ruta="View/IMGsubido/";
                move_uploaded_file($_FILES["image"]["tmp_name"], $ruta . $_FILES["image"]["name"]);
            }else{
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Solo se pueden subir Imagenes de formato JPEG, JPG, PNG Y GIF');
                        });
                    </script>";
            }
            if(!isset($_POST["talla"])){
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Selecciona una Talla');
                        });
                    </script>";
            }else{
                $tallas=$_POST["talla"];

                //AGREGAR PROMO Y VALIDAR QUE NO SE REPITAN
                $resultverif=$conexion->prepare("SELECT * FROM MUJER WHERE NOMBRE='$titulo'");
                $resultverif->execute();
                $verifica=$resultverif->rowCount();
                if($verifica!=0){
                    echo "<script>
                            $(function(){
                                alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>La Promocion ya Existe!!!.');
                            });
                        </script>";
                }else{
                    $sqlpromo="INSERT INTO MUJER(NOMBRE, DETALLE, NUNIDAD, PRECIO, IMAGEN) 
                    VALUES(:NOM, :DETALL, :UNID, :PRECIO, :IMG)";
                    $resulpromo=$conexion->prepare($sqlpromo);
                    $resulpromo->execute(array(":NOM"=>$titulo, ":DETALL"=>$descrip, ":UNID"=>$unidades, ":PRECIO"=>$precio, ":IMG"=>$nom_img));

                    //OBTENER EL ID DE LA PROMO PARA AGREGARLO EN LAS TABLAS DEPENDIENTES
                    $sqlver="SELECT * FROM MUJER ORDER BY ID_MUJER DESC LIMIT 1";
                    $resultver=$conexion->prepare($sqlver);
                    $resultver->execute();
                    while($prom=$resultver->fetch(PDO::FETCH_ASSOC)){
                        $id_promo=$prom["id_mujer"];
                    }

                    //INGRESAR LAS TALLAS A LA BD
                    foreach($tallas as $talla){
                        $sqltalla="INSERT INTO TALLAMUJER(ID_MUJER, ID_TALLA) VALUES(:IDMUJER, :IDTALLA)";
                        $resulttalla=$conexion->prepare($sqltalla);
                        $resulttalla->execute(array(":IDMUJER"=>$id_promo, ":IDTALLA"=>$talla));
                    }
                    echo '<meta http-equiv="Refresh" content="0; URL=index.php?pag=model/agre_mujer.php">';
                }
                
            }
        }else{
            echo "<script>
                    $(function(){
                        alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>El tamaño de la imagen es muy grande.');
                    });
                </script>";
        }
    }

?>

<!--LINKS DE ESTILOS CSS3-->
<link rel="stylesheet" href="View/CSS/agre_producto.css">
<!--LINKS DE JAVASCRIPT-->
<script src="View/JavaScript/ingreso_de_imagenes.js"></script>

    <article class="contenido"><!-- CONTENEDOR GENERAL -->
    <form action="" method="post" class="form-color form-talla" enctype="multipart/form-data">
    <div class="general">
        <div class="camiseta"><!--CONTENEDOR DE CAMISETA-->
            <!--DISEÑO DE CAMISETA-->
            <p class="previ">Previsualización</p>
            <div class="borde">
                <section class="zonaedit" id="zonaedit">
                    <p class="textedit">Zona de<br>Imagen </p>
                </section>
            </div>
            
            <!--FIN DISEÑO DE CAMISETA-->

            <div class="contenboton">
                <div class="botonimg">
                    <p class="textbot">Agregar Imagenes</p>
                    <img class="iconimg" src="View/IMG/IMG2/icon_img.png" alt="">
                    <input type="file" class="archivos" name="image" id="archivos" required>
                </div>
            </div>
        </div>

        <!--CONTENEDOR DE DETALLES CAMISETA-->
        <div class="detacamisa">
            <p class="titulocamiseta">Agregar Productos</p>
           

            <label for="nombre" class="subdetalles">Nombre o Titulo del Producto:</label><br>
            <input class="inputproduct" type="text" name="nombre" placeholder="Nombre o Titulo" required><br><br>
            
            <!--______________OPCIONES DE TALLAS__________________________________________________________________-->
            <p class="subdetalles">Establecer tallas disponible:</p>
            
                <section class="tallas">
                    <input type="checkbox" name="talla[]" id="5" value="1" checked>
                    <label for="5">
                        <div class="s"><p>7</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>
                    
                    <input type="checkbox" name="talla[]" id="6" value="2">
                    <label for="6">
                        <div class="m"><p>8</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>

                    <input type="checkbox" name="talla[]" id="7" value="3">
                    <label for="7">
                        <div class="l"><p>9</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>
                </section>
           

            <!--______________MAS DETALLES__________________________________________________________________-->
            <p class="subdetalles">Agregar mas detalles:</p>
            <section class="masdeta">
               <textarea name="descrip" id="descrip" cols="30" placeholder="Descripcion del producto" required></textarea>
            </section>

            <!--______________UNIDADES__________________________________________________________________-->
            <p class="subdetalles">N° de Unidades:</p>
            <section class="unidades">
               <input class="inputproduct" style="width: 100px" type="number" name="canti" id="canti" nim=0 placeholder="Unidades" required>
            </section>

            <!--______________PRECIOS__________________________________________________________________-->
            <p class="subdetalles">Precio:</p>
            <section class="unidades">
               <input class="inputproduct" style="width: 100px" type="number" name="precio" id="precio" nim=0 step="any" placeholder="$" required>
            </section>
            <section>
                <input style="    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;" type="submit" value="Agregar" name="agregarpromo">
            </section>
            
        </div>
    </form>


        <!--MOSTRAR LOS PRODUCTOS-->
        <div class="mostrarcami"><!--CONTENEDOR MOSTRAR PRODUCTOS-->
        <?php foreach($arraypromo as $verpromo): ?>
            <div class="contver">
                <div>
                    <img src="View/IMGsubido/<?php echo $verpromo['imagen'] ?>" alt="">
                </div>
                <div>
                    <h4 class="textcamiver"><?php echo $verpromo["nombre"]; ?></h4>

                    <section class="tallasver">
                        <?php
                            $sqltalla=$conexion->query("SELECT * FROM TALLAMUJER WHERE ID_MUJER=". $verpromo["id_mujer"]);
                            while($filatalla=$sqltalla->fetch(PDO::FETCH_ASSOC)){
                                if($filatalla["id_talla"]==1){
                                    echo '<div class="sver"><p>7</p></div>';
                                }
                                if($filatalla["id_talla"]==2){
                                    echo '<div class="mver"><p>8</p></div>';
                                }
                                if($filatalla["id_talla"]==3){
                                    echo '<div class="lver"><p>9</p></div>';
                                }
                                
                            }
                        ?>
                    </section>

                    <h4 class="textcamiver">Total Unidades: <?php echo $verpromo["nunidad"] ?></h4>
                    <h4 class="textcamiver">Precio: $<?php echo $verpromo["precio"]; ?></h4>

                    <button class="btnverprod" style="background-color:#44c767;
    -moz-border-radius:10px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:17px;
    font-style:italic;
    padding:auto;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
    float: right; float: right"><a style="text-decoration: none; color: #070044c5" href="index.php?pag=Model/elim_mujer.php & id=<?php echo $verpromo["id_mujer"]; ?> ">Borrar</a></button>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
    </article>