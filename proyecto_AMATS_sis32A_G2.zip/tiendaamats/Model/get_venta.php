<?php

    class  Venta{
        private $db;
        private $venta;

        public function __construct(){
            require_once("Model/conexion.php");
            $this->db=Conectar::conexion();
            $this->venta=array();
        }

        public function get_venta(){
            $sql=$this->db->query("SELECT * FROM VENTA");
            while($fila=$sql->fetch(PDO::FETCH_ASSOC)){
                $this->venta[]=$fila;
            }
            return $this->venta;
        }
    }

?>