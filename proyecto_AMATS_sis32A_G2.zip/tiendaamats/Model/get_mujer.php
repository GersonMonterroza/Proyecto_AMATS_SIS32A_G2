<?php

    class Promo{
        private $db;
        private $mujer;

        public function __construct(){
            require_once("Model/conexion.php");
            $this->db=Conectar::conexion();
            $this->mujer=array();
        }

        public function get_promo(){
            $sqlvermujer=$this->db->query("SELECT * FROM MUJER ORDER BY ID_MUJER DESC");
            while($fila=$sqlvermujer->fetch(PDO::FETCH_ASSOC)){
                $this->mujer[]=$fila;
            }
            return $this->mujer;
        }
    }

?>