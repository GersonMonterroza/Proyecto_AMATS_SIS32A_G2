<?php
    //PHP PARA REGISTRAR LOS USUARIOS 
    require("Model/conexion.php");
    $conexion=Conectar::conexion();

    if(isset($_POST["regis"])){
        $nombre=$_POST["nom"];
        $apellido=$_POST["apell"];
        $correo=$_POST["correo"];
        $contraseña=$_POST["pass"];

        //ENCRIPTAR CONTRASEÑA
        $pass_encript=password_hash($contraseña, PASSWORD_DEFAULT, array("cost"=>12));

        //VALIDAR SI YA EXISTE EL USUARIO
        $ruser=$conexion->prepare("SELECT * FROM USUARIO WHERE CORREO='$correo'");
        $ruser->execute();
        $n_user=$ruser->rowCount();
        if($n_user!=0){
            echo "<script>
                    $(function(){
                        alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>El Correo ya Existe!!!.');
                    });
                </script>";
        }else{
            //CREAMOS LA CONSULTA SQL
            $sql="INSERT INTO USUARIO (NOMBRE, APELLIDO, CORREO, CONTRASENA) VALUES (:NOM, :APELL, :CORR, :CONTRA)";
            //PREPARAMOS LA CONSULTA SQL
            $resultsql=$conexion->prepare($sql);
            //RELLENAR LOS CAMPOS DE LA CONSULTA SQL
            $resultsql->execute(array(":NOM"=>$nombre, ":APELL"=>$apellido, ":CORR"=>$correo, ":CONTRA"=>$pass_encript));
            $_SESSION["user"]=$nombre;
        }
        $sqlverid="SELECT * FROM USUARIO ORDER BY ID DESC LIMIT 1";
        $verid=$conexion->prepare($sqlverid);
        $verid->execute();
        while($iduserver=$verid->fetch(PDO::FETCH_ASSOC)){
            $idveruser=$iduserver["id"];
        }
        $_SESSION["iduser"]=$idveruser;
        echo "<script>
                    $(function(){
                        alertify.success('Usuario Agregado Correctamente.');
                    });
                </script>";
    }

    //PHP PARA EL LOGIN DE LOS USUARIOS
    if(isset($_POST["entrar"])){
        //CREAR LA CONSULTA SQL
        $sql="SELECT * FROM USUARIO WHERE CORREO=:CORR";
        $resultsql=$conexion->prepare($sql);

        //PREPARAR LOS DATOS PARA RESIVIR CARACTERES ESPECIALES
        $corr=htmlentities(addslashes($_POST["correo"]));
        $pass=htmlentities(addslashes($_POST["pass"]));

        //ASIGNAR LOS DATOS A LOS MARCADORES DE LA CONSULTA
        $resultsql->bindValue(":CORR", $corr);

        //EJECUTAR LA CONSULTA
        $resultsql->execute();

        //RECORRER LA TABLA DE USUARIO PARA SACAR EL NOMBRE DEL USUARIO
        $num_user=0;
        while($user=$resultsql->fetch(PDO::FETCH_ASSOC)){
            if(password_verify($pass, $user["contrasena"])){//DESENCRIPTAR CONTRASEÑA
                $usuario=$user["nombre"];
                $iduser=$user["id"];
                $num_user++;
            }
        }
        
        //VALIDAR SI EXISTE EL USUARIO
        //$num_user=$resultsql->rowCount();
        if($num_user!=0){
            if($iduser==1){
                $_SESSION["admin"]="Administrador";
                echo "<script>
                    $(function(){
                        alertify.success('Bienvenido/a ADMIN.');
                    });
                </script>";
            }else{
                $_SESSION["user"]=$usuario;
                $_SESSION["iduser"]=$iduser;
                echo "<script>
                    $(function(){
                        alertify.success('Bienvenido/a.');
                    });
                </script>";
            }
        }else{
            echo "<script>
                $(function(){
                    alertify.error('No estas Resgistrado.');
                });
            </script>";
        }
    }
?>
    <!-- LOGIN -->
    <div class="modal fade" id="login">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h1 class="iniuser">Iniciar Sesion</h1>
        </div>
        <div class="modal-body">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" id="user" method="post" class="form-horizontal" role="form">
                <table >
                    <tr>
                        <td align="left"><label class="iniuser" for="">Correo</label></td>
                        <td><input class="inputuser" type="email" name="correo" id="correo" required placeholder="xxxxxxx@gmail.com"></td>
                    </tr>
                    <td></td>
                    <tr><td height=50></td></tr>
                    <tr>
                        <td align="right"><label class="iniuser" for="">Contraseña</label></td>
                        <td><input class="inputuser" type="password" name="pass" id="pass" required placeholder="Ingresa tu password"></td>
                    </tr>
                </table>
            
        </div>
        <div class="modal-footer">
            <table class="tbluser">
                <tr>
                    <td><input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="submit" value="Aceptar" name="entrar"></td>
                    <td> <input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="reset" value="Cancelar" data-dismiss="modal"></td>
                </tr>
            </table>
            </form>
        </div>
        </div>
    </div>
    </div>
    <!-- REGISTRARSE -->
    <div class="modal fade" id="registrarse">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="iniuser" id="exampleModalLabel">Registrarse</h5>
        </div>
        <div class="modal-body">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
                <table class="tbluser">
                    <tr>
                        <td align="left"><label class="iniuser" for="">Nombre</label></td>
                        <td><input class="inputuser" type="text" name="nom" id="nom" required ></td>
                    </tr>
                    <tr><td height=10></td></tr>
                    <tr>
                        <td align="left"><label class="iniuser" for="">Apellido</label></td>
                        <td><input class="inputuser" type="text" name="apell" id="apell" required ></td>
                    </tr>
                    <tr><td height=10></td></tr>
                    <tr>
                        <td align="left"><label class="iniuser" for="">Correo</label></td>
                        <td><input class="inputuser" type="email" name="correo" id="correo" required ></td>
                    </tr>
                    <tr><td height=10></td></tr>
                    <tr>
                        <td align="left"><label class="iniuser" for="">Contraseña</label></td>
                        <td><input class="inputuser" type="password" name="pass" id="pass" required ></td>
                    </tr>
                </table>
            
        </div>
        <div class="modal-footer">
            <table class="tbluser">
                <tr>
                    <td><input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="submit" value="Aceptar" name="regis"></td>
                    <td> <input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="reset" value="Cancelar" data-dismiss="modal"></td>
                </tr>
            </table>
            </form>
        </div>
        </div>
    </div>
    </div>

