<?php

    class User{
        private $db;
        private $user;

        public function __construct(){
            require_once("Model/conexion.php");
            $this->db=Conectar::conexion();
            $this->user=array();
        }

        public function get_user(){
            $sqlveruser=$this->db->query("SELECT * FROM USUARIO ORDER BY ID DESC");
            while($user=$sqlveruser->fetch(PDO::FETCH_ASSOC)){
                $this->user[]=$user;
            }
            return $this->user;
        }
    } 

?>