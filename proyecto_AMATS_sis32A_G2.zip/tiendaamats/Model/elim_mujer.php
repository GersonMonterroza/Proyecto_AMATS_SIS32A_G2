<?php
    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }
    $id=$_GET["id"];
    $conexion->query("DELETE FROM MUJER WHERE ID_MUJER=$id");
    $conexion->query("DELETE FROM TALLAMUJER WHERE ID_MUJER=$id");
    echo '<meta http-equiv="Refresh" content="0; URL=index.php?pag=model/agre_mujer.php">';

?>