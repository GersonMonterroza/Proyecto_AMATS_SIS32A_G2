
<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>
    
    paypal.Button.render({
        env: 'sandbox', // sandbox | production
        style: {
            label: 'pay',  // checkout | credit | pay | buynow | generic
            size:  'responsive', // small | medium | large | responsive 
            shape: 'pill',   // pill | rect
            color: 'blue'   // gold | blue | silver | black
        },
 
        //INGRESAR CREDENCIALES DE USUARIO DE PAYPAL
        client: {    //cambiar para que el dinero vaya a mi cuenta
            sandbox:    'AcS97zlGSRyyRAJX9DFxxhGnmKE7j3mCDYLPoUwXzx8wuPPSG_ck-9n5GrIKSuckxxgSzqqzdJ4-hj0A',
            production: 'ARWpsKnd-Fn4Uag2jvxoGyTSkd-5rXUeD6EVWQJbgIvkPZXAo4FM0ZKjoUau8oNE5qWpGLpHhBwt14u0'
        },
 
        //DATOS PARA REALIZAR EL PAGO
        payment: function(data, actions) {
            return actions.payment.create({
                payment: {
                    transactions: [
                        {
                            amount: { total: '<?php echo $_SESSION["totalfinal"]; ?>', currency: 'USD' },
                            description:"Compra de <?php echo $_SESSION["totalproduct"]; ?> productos. Total: $<?php echo $_SESSION["totalfinal"]; ?>",
                            custom:"<?php $_SESSION["iduser"]; ?>"
                        }
                    ]
                }
            });
        },
 
        //RESULTADO DE LOS DETALLES DE PAGO
        onAuthorize: function(data, actions) {
            return actions.payment.execute().then(function() {
                console.log(data);
                window.location="Model/proceso_ventafinal.php?paymentToken="+data.paymentToken+" & id="+data.paymentID
            });
        }
   
    }, '#paypal-button-container');


</script>
<link rel="stylesheet" href="View/CSS/propago.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
    <div class="modal-header">
        <h5 class="titu" id="exampleModalLabel">Datos de tu Compra</h5>
    </div>
    <br><br> <br>
    <div class="modal-body">
        <p align=center class="ttdir">
          
            Realizaras una compra de <?php echo $_SESSION["totalproduct"]; ?> productos <br>
            por el monto de <br>
            <span>$<?php echo $_SESSION["totalfinal"]; ?></span>
        </p>
        <br><br>
        <div id="paypal-button-container"></div>
        <script>
            paypal.Buttons().render('#paypal-button-container');
        </script>
    </div>
</article>