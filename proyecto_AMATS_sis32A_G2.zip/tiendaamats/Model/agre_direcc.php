<?php

    if(isset($_POST["agregar"])){
        $nombre=$_POST["nom"];
        $apellido=$_POST["apell"];
        $calle=$_POST["calle"];
        $ciudad=$_POST["ciudad"];
        $pais=$_POST["pais"];
        $region=$_POST["dep"];
        $codpostal=$_POST["codpostal"];
        $tel=$_POST["tel"];

        $sql="INSERT INTO DIRECCION(NOMBRE, APELLIDO, CALLE, CIUDAD, PAIS, REGION, CODPOSTAL, TELEFONO) 
        VALUES(:NOM, :APELL, :CALLE, :CIUDAD, :PAIS, :REGION, :CPOSTAL, :TEL)";
        $resulsql=$conexion->prepare($sql);
        $resulsql->execute(array(":NOM"=>$nombre, ":APELL"=>$apellido, ":CALLE"=>$calle, ":CIUDAD"=>$ciudad, ":PAIS"=>$pais, ":REGION"=>$region, ":CPOSTAL"=>$codpostal, ":TEL"=>$tel));

        $verdir="SELECT * FROM DIRECCION ORDER BY ID DESC LIMIT 1";
        $resulverdir=$conexion->prepare($verdir);
        $resulverdir->execute();
        while($iddir=$resulverdir->fetch(PDO::FETCH_ASSOC)){
            $iddirecc=$iddir["id"];
        }

        $sqluserdir="INSERT INTO USERDIRECC (ID_USER, ID_DIRECC) VALUES (".$_SESSION["iduser"].", $iddirecc)";
        $resuluserdir=$conexion->prepare($sqluserdir);
        $resuluserdir->execute();

    }

?>

<div class="modal fade" id="direcc">
    <div class="modal-dialogdir" role="document">
        <div class="modal-contentdir">
        <div class="modal-header">
            <h5 class="titu" id="exampleModalLabel">Agregar Direccion</h5>
        </div>
        <div class="modal-body">
            <form method="post">
                <table class="tbldirec">
                    <tr>
                        <td align="right"><label class="textdir" for="">Nombre</label><input class="inputuser" type="text" name="nom" id="nom" required placeholder="Nombre"></td>
                        <td align="right"><label class="textdir" for="">Apellido</label><input class="inputuser" type="text" name="apell" id="apell" required placeholder="Apellido"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Calle</label><br><input style="" class="inputuser" type="text" name="calle" id="calle" required placeholder="Calle"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Ciudad</label><br><input style="width: 200px;" class="inputuser" type="text" name="ciudad" id="ciudad" required placeholder="Ciudad"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Pais</label><br><input class="inputuser" type="text" name="pais" id="pais" required placeholder="Pais"></td>
                        <td align="right"><label class="textdir" for="">Departamento</label><br><input style="width: 200px;" class="inputuser" type="text" name="dep" id="dep" required placeholder="Depart. o Region"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Codigo Postal</label><br><input style="width: 150px;" class="inputuser" type="number" name="codpostal" id="codpostal" required placeholder="Codigo"></td>
                        <td align="right"><label class="textdir" for="">Telefono</label><br><input style="width: 150px;" class="inputuser" type="number" name="tel" id="tel" required placeholder="Telefono"></td>
                    </tr>
                </table>
        </div>
        <div class="modal-footer">
            <table class="tbluser">
                <tr>
                    <td><input class="btnuser"type="submit" value="Agregar" name="agregar"></td>
                    <td> <input class="btnuser"type="reset" value="Cancelar" data-dismiss="modal"></td>
                </tr>
            </table>
            </form>
        </div>
        </div>
    </div>
</div>