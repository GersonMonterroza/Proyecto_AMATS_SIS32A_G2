<?php
    $id=$_GET["id"];
    $conexion->query("DELETE FROM DIRECCION WHERE ID=$id");
    echo '<meta http-equiv="Refresh" content="0; URL=index.php?pag=View/datouser.php">';
?>
