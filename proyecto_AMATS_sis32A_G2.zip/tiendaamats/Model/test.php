<?php
  	use PHPUnit\Framework\TestCase; 

	final class PruebaTest extends TestCase{

		public function testConexion(){
			$prueba=new Conectar();
			$this->assertEquals($prueba->conexion(),true);
		}

	}

?>