<?php

    class Producto{
        private $db;
        private $product;

        public function __construct(){
            require_once("Model/conexion.php");
            $this->db=Conectar::conexion();
            $this->product=array();
        }

        public function get_producto(){
            $sqlproduct=$this->db->query("SELECT * FROM PRODUCTOS ORDER BY ID_PRODUCTO DESC");
            while($fila=$sqlproduct->fetch(PDO::FETCH_ASSOC)){
                $this->product[]=$fila;
            }
            return $this->product;
        }
    }

?>