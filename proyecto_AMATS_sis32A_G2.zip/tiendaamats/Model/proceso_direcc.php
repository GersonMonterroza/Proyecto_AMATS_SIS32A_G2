<?php
    //VALIDAR SI EXISTEN LAS DIRECCIONES PARA PODER USARLAS
    if(isset($_POST["usardir"])){
        $id=$_POST["direnvio"];
        $resulusardir=$conexion->query("SELECT * FROM DIRECCION WHERE ID=". $id);
        $dir=$resulusardir->fetch(PDO::FETCH_ASSOC);
        $iddir=$dir["id"];
        $nom=$dir["nombre"];
        $apell=$dir["apellido"];
        $calle=$dir["calle"];
        $ciud=$dir["ciudad"];
        $pais=$dir["pais"];
        $region=$dir["region"];
        $codp=$dir["codpostal"];
        $tel=$dir["telefono"];

    }else{
        $iddir="";
        $nom="";
        $apell="";
        $calle="";
        $ciud="";
        $pais="";
        $region="";
        $codp="";
        $tel="";
    }

    //SACAR LOS DATOS DE LA DIRECCION
    if(isset($_POST["venta"])){
        $id=$_POST["id"];
        if($id==""){
            $nombre=$_POST["nom"];
            $apellido=$_POST["apell"];
            $calle=$_POST["calle"];
            $ciudad=$_POST["ciudad"];
            $pais=$_POST["pais"];
            $region=$_POST["dep"];
            $codpostal=$_POST["codpostal"];
            $tel=$_POST["tel"];

            $sql="INSERT INTO DIRECCION(NOMBRE, APELLIDO, CALLE, CIUDAD, PAIS, REGION, CODPOSTAL, TELEFONO) 
            VALUES(:NOM, :APELL, :CALLE, :CIUDAD, :PAIS, :REGION, :CPOSTAL, :TEL)";
            $resulsql=$conexion->prepare($sql);
            $resulsql->execute(array(":NOM"=>$nombre, ":APELL"=>$apellido, ":CALLE"=>$calle, ":CIUDAD"=>$ciudad, ":PAIS"=>$pais, ":REGION"=>$region, ":CPOSTAL"=>$codpostal, ":TEL"=>$tel));

            $verdir="SELECT * FROM DIRECCION ORDER BY ID DESC LIMIT 1";
            $resulverdir=$conexion->prepare($verdir);
            $resulverdir->execute();
            while($iddir=$resulverdir->fetch(PDO::FETCH_ASSOC)){
                $iddirecc=$iddir["id"];
            }

            $sqluserdir="INSERT INTO USERDIRECC (ID_USER, ID_DIRECC) VALUES (".$_SESSION["iduser"].", $iddirecc)";
            $resuluserdir=$conexion->prepare($sqluserdir);
            $resuluserdir->execute();
            $_SESSION["dirselect"]=$iddirecc;
            echo "<script>location.href='index.php?pag=Model/procesar_pago.php';</script>";
        }else{
            $_SESSION["dirselect"]=$_POST["id"];
            echo "<script>location.href='index.php?pag=Model/procesar_pago.php';</script>";
        }
    }

?>
<link rel="stylesheet" href="View/CSS/datouser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <div class="modal-header">
            <h5 class="titu" id="exampleModalLabel">Seleccione Direccion de Envio</h5>
        </div>
        <div class="modal-body">
            <table class="tbldirec">
            <form action="" method="post">
                    <tr>
                        <td align="center" colspan="">
                            <label class="textdir" for="">Tus Direcciones</label><br>
                            <select  class="unidades" name="direnvio" id="">
                            <?php foreach($arraydirecc as $direcc): ?>
                                <?php
                                    $verdir=$conexion->query("SELECT * FROM USERDIRECC WHERE ID_USER=".$_SESSION["iduser"]);
                                    while($veruserdir=$verdir->fetch(PDO::FETCH_ASSOC)){
                                        if($direcc["id"]==$veruserdir["id_direcc"]){
                                ?>
                                            <option value="<?php echo $direcc["id"]?>"><?php echo $direcc["nombre"]?> <?php echo $direcc["apellido"]?></option>
                                <?php
                                        } 
                                    }
                                ?>
                            <?php endforeach; ?>
                            </select><br><br><br>
            
                        </td>
                        <td style="vertical-align: middle;">
                            <input style="    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;" type="submit" name="usardir"value="Usar Direccion">
                        </td>
                    </tr>
            </form>
            <form method="post">
                <input type="hidden" name="id" value=<?php echo $iddir; ?>>   
                    <tr>
                        <td align="right"><label class="textdir" for="">Nombre</label><input class="inputuser" type="text" value="<?php echo $nom; ?>" name="nom" id="nom" required placeholder="Nombre"></td>
                        <td align="right"><label class="textdir" for="">Apellido</label><input class="inputuser" type="text" value="<?php echo $apell; ?>" name="apell" id="apell" required placeholder="Apellido"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Calle</label><br><input style="" class="inputuser" type="text" value="<?php echo $calle; ?>" name="calle" id="calle" required placeholder="Calle"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Ciudad</label><br><input style="width: 200px;" class="inputuser" type="text" value="<?php echo $ciud; ?>" name="ciudad" id="ciudad" required placeholder="Ciudad"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Pais</label><br><input class="inputuser" type="text" value="<?php echo $pais; ?>" name="pais" id="pais" required placeholder="Pais"></td>
                        <td align="right"><label class="textdir" for="">Departamento</label><br><input style="width: 200px;" class="inputuser" type="text" value="<?php echo $region; ?>" name="dep" id="dep" required placeholder="Depart. o Region"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Codigo Postal</label><br><input style="width: 150px;" class="inputuser" type="number" value="<?php echo $codp; ?>" name="codpostal" id="codpostal" required placeholder="Codigo"></td>
                        <td align="right"><label class="textdir" for="">Telefono</label><br><input style="width: 150px;" class="inputuser" type="number" value="<?php echo $tel; ?>" name="tel" id="tel" required placeholder="Telefono"></td>
                    </tr>
                </table>
        </div>
        <div class="modal-footer">
            <table class="tbluser">
                <tr>
                    <td colspan="2">
                        <button style="    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;" name="venta">
                            <p>Siguir para Pagar</p>
                            <!--<img src="View/IMG/IMG2/paypal.png" alt="Carrito de Compras">-->
                        </button>
                    </td>
                </tr>
            </table>
            </form>
        </div>
</article>