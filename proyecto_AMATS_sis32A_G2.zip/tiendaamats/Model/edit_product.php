<?php

    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }

    if(!isset($_POST["agregarproduct"])){
        $id=$_GET["id"];
        $nombre=$_GET["nom"];
        $detalle=$_GET["detall"];
        $nunidad=$_GET["unid"];
        $img=$_GET["img"];
        $precio=$_GET["prec"];
    }else{
        $img=$_GET["img"];
        $id=$_POST["id"];
        $nombre=$_POST["nombre"];
        $detalle=$_POST["descrip"];
        $nunidad=$_POST["canti"];
        $precio=$_POST["precio"];

        
        
        //SQL´S DE TALLA
        $sqlcontalla=$conexion->query("SELECT * FROM TALLAPRODUCT WHERE ID_PRODUCTO=". $id);
        $ntalla=$sqlcontalla->rowcount();
        $sqlveritalla=$conexion->query("SELECT * FROM TALLAPRODUCT WHERE ID_PRODUCTO=". $id);

        //DATOS DE LA IMAGEN
        if(!$_FILES["image"]["name"]==""){
            $nom_img=$_FILES["image"]["name"];
            $tipo_img=$_FILES["image"]["type"];
            $tamaño_img=$_FILES["image"]["size"];

            if($tamaño_img<=5000000){//VALIDAR EL TAMAÑO DE LA IMAGEN
                
                if($tipo_img=="image/jpeg" || $tipo_img=="image/jpg" || $tipo_img=="image/png"){//VALIDAR EL TIPO DE IMAGEN
                    $ruta="View/IMGsubido/";
                    move_uploaded_file($_FILES["image"]["tmp_name"], $ruta . $_FILES["image"]["name"]);
                }else{
                    echo "<script>
                            $(function(){
                                alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Solo se pueden subir Imagenes de formato JPEG, JPG, PNG Y GIF');
                            });
                        </script>";
                }
                
            }else{
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>El tamaño de la imagen es muy grande.');
                        });
                    </script>";
            }
        }else{
            $nom_img=$_GET["img"];
        }
        
            
        
        if(isset($_POST["elitalla"])){//VALIDAR QUE LA CAMISETA NO QUEDE SIN TALLA
            $elitalla=$_POST["elitalla"];
            $n_elitalla=count($elitalla);
            
            if($n_elitalla==$ntalla and !isset($_POST["talla"])){
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Si eliminas todas las tallas disponibles, agrega una nuevo!!!.');
                        });
                    </script>";
            }else{
                foreach($elitalla as $delete){
                    $brrtalla="DELETE FROM TALLAPRODUCT WHERE ID_TALLA=:ID AND ID_PRODUCTO=:ID_PRO";
                    $rbrrtalla=$conexion->prepare($brrtalla);
                    $rbrrtalla->execute(array(":ID"=>$delete, ":ID_PRO"=>$id));
                }   
            }
        }

        if(isset($_POST["talla"])){//VALIDAR QUE NO SE AGREGUE UNA TALLA REPETIDA
            $talla=$_POST["talla"];

            foreach($talla as $tll){
                $sqlvalidar="SELECT * FROM  TALLAPRODUCT WHERE ID_PRODUCTO=:ID_PRO AND ID_TALLA=:ID_TALLA";
                $resultadotalla=$conexion->prepare($sqlvalidar);
                $resultadotalla->execute(array(":ID_PRO"=>$id, ":ID_TALLA"=>$tll));
            }

            $n_talla=$resultadotalla->rowcount();
            if($n_talla!=0){
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>La talla que agregaras ya existe!!!.');
                        });
                    </script>";
            }else{
                foreach($talla as $tall){
                    $insertalla="INSERT INTO TALLAPRODUCT(ID_PRODUCTO, ID_TALLA) VALUES(:ID, :TALLA)";
                    $rinsertalla=$conexion->prepare($insertalla);
                    $rinsertalla->execute(array(":ID"=>$id, ":TALLA"=>$tall));
                }
            }
        }

        $sqlupd="UPDATE PRODUCTOS SET NOMBRE=:NOM, DETALLE=:DET, NUNIDAD=:UNI, PRECIO=:PRE, IMAGEN=:IMG WHERE ID_PRODUCTO=:ID";
        $resultupd=$conexion->prepare($sqlupd);
        $resultupd->execute(array(":ID"=>$id, ":NOM"=>$nombre, ":DET"=>$detalle, ":UNI"=>$nunidad, ":PRE"=>$precio, ":IMG"=>$nom_img));

        echo "<script>location.href='index.php?pag=model/agre_product.php';</script>";
    }

    if(isset($_POST["volver"])){
        echo "<script>location.href='index.php?pag=model/agre_product.php';</script>";
    }

?>
<!--LINKS DE ESTILOS CSS3-->
<link rel="stylesheet" href="View/CSS/edit_product.css">
<!--LINKS DE JAVASCRIPT-->
<script src="View/JavaScript/ingreso_de_imagenes.js"></script>

    <article class="contenido"><!-- CONTENEDOR GENERAL -->
    <form class="form-color form-talla" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <div class="general">
        <div class="camiseta"><!--CONTENEDOR DE CAMISETA-->
            <!--DISEÑO DE CAMISETA-->
            <p class="previ">Previsualización</p>
            <div class="borde"> 
                <section class="zonaedit" id="zonaedit">
                    <img id="camiseta" class="imgg" src="View/IMGsubido/<?php echo $img; ?>" alt="Camiseta">
                </section>
            </div>
            
            <!--FIN DISEÑO DE CAMISETA-->

            <div class="contenboton">
                <div class="botonimg">
                    <p class="textbot">Cambiar Imagen</p>
                    <img class="iconimg" src="View/IMG/IMG2/icon_img.png" alt="">
                    <input type="file" class="archivos" name="image" id="archivos">
                </div>
            </div>
        </div>

        <!--CONTENEDOR DE DETALLES CAMISETA-->
        <div class="detacamisa">
            <p class="titulocamiseta">Editar Producto</p>
           

            <label for="nombre" class="subdetalles">Editar Nombre:</label><br>
            <input class="inputproduct" type="text" name="nombre" value="<?php echo $nombre; ?>" required><br><br>
            

            <!--______________ELIMINAR TALLAS__________________________________________________________________-->
            <p class="subdetalles">Eliminar tallas disponible:</p>
            
                <section class="tallas">
                    <?php 
                        $sqltalla=$conexion->query("SELECT * FROM TALLAPRODUCT WHERE ID_PRODUCTO=". $id);
                        while($filatalla=$sqltalla->fetch(PDO::FETCH_ASSOC)){
                            if($filatalla["id_talla"]==1){
                                echo '
                                <input type="checkbox" name="elitalla[]" id="elis" value=1>
                                <label for="elis">
                                    <div class="s"><p>7</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                                </label>
                                ';
                            }
                            if($filatalla["id_talla"]==2){
                                echo '
                                <input type="checkbox" name="elitalla[]" id="elim" value=2>
                                <label for="elim">
                                    <div class="m"><p>8</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                                </label>
                                ';
                            }
                            if($filatalla["id_talla"]==3){
                                echo '
                                <input type="checkbox" name="elitalla[]" id="elil" value=3>
                                <label for="elil">
                                    <div class="l"><p>9</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                                </label>
                                ';
                            }  
                        }
                    ?>
                </section>
            <!--______________AGREGAR TALLAS__________________________________________________________________-->
            <p class="subdetalles">Agregar tallas disponible:</p>
            
                <section class="tallas">
                    <input type="checkbox" name="talla[]" id="s" value="1">
                    <label for="s">
                        <div class="s"><p>7</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>
                    
                    <input type="checkbox" name="talla[]" id="m" value="2">
                    <label for="m">
                        <div class="m"><p>8</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>

                    <input type="checkbox" name="talla[]" id="l" value="3">
                    <label for="l">
                        <div class="l"><p>9</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                    </label>
                </section>
           

            <!--______________MAS DETALLES__________________________________________________________________-->
            <p class="subdetalles">Agregar mas detalles:</p>
            <section class="masdeta">
               <textarea name="descrip" id="descrip" cols="30" required><?php echo $detalle; ?></textarea>
            </section>

            <!--______________UNIDADES__________________________________________________________________-->
            <p class="subdetalles">N° de Unidades:</p>
            <section class="unidades">
               <input class="inputproduct" style="width: 100px" type="number" name="canti" id="canti" nim=0 value=<?php echo $nunidad; ?> required>
            </section>

            <!--______________PRECIOS__________________________________________________________________-->
            <p class="subdetalles">Precio:</p>
            <section class="unidades">
               <input class="inputproduct" style="width: 100px" type="number" name="precio" id="precio" nim=0 step="any" value="<?php echo $precio; ?>" required>
            </section>
            <section>
                <table>
                    <tr>
                        <td><input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="submit" value="Editar Datos" name="agregarproduct"></td>
                        <td><input style="
    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;

" type="submit" value="Volver" name="volver"></td>
                    </tr>
                </table>
            </section>
            
        </div>
    </form>
    </div>
    </article>