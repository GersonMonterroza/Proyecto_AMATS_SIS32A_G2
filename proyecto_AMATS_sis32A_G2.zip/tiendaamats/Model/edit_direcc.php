<?php

    if(!isset($_POST["edit_direcc"])){
        $id=$_GET["id"];
        $nombre=$_GET["nom"];
        $apellido=$_GET["apell"];
        $calle=$_GET["calle"];
        $ciudad=$_GET["ciudad"];
        $pais=$_GET["pais"];
        $region=$_GET["region"];
        $codpostal=$_GET["codpostal"];
        $telef=$_GET["tel"];
    }else{
        $id=$_POST["id"];
        $nombre=$_POST["nom"];
        $apellido=$_POST["apell"];
        $calle=$_POST["calle"];
        $ciudad=$_POST["ciudad"];
        $pais=$_POST["pais"];
        $region=$_POST["dep"];
        $codpostal=$_POST["codpostal"];
        $telef=$_POST["tel"];

        $sql="UPDATE DIRECCION SET NOMBRE=:NOM, APELLIDO=:APELL, CALLE=:CALLE, CIUDAD=:CIUDAD, PAIS=:PAIS, REGION=:REGION, CODPOSTAL=:CPOSTAL, TELEFONO=:TEL 
        WHERE ID=:ID";
        $resulsql=$conexion->prepare($sql);
        $resulsql->execute(array(":ID"=>$id, ":NOM"=>$nombre, ":APELL"=>$apellido, ":CALLE"=>$calle, ":CIUDAD"=>$ciudad, ":PAIS"=>$pais, ":REGION"=>$region, ":CPOSTAL"=>$codpostal, ":TEL"=>$telef));
        
        echo "<script>location.href='index.php?pag=View/datouser.php';</script>";
    }
    if(isset($_POST["cancel"])){
        echo "<script>location.href='index.php?pag=View/datouser.php';</script>";
    }

?>

<link rel="stylesheet" href="View/CSS/datouser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <div class="modal-header">
            <h5 class="titu" id="exampleModalLabel">Editar Direccion</h5>
        </div>
        <div class="modal-body">
            <form method="post">
                <input type="hidden" name="id" value=<?php echo $id; ?>>
                <table class="tbldirec">
                    <tr>
                        <td align="right"><label class="textdir" for="">Nombre</label><input class="inputuser" type="text" value="<?php echo $nombre; ?>" name="nom" id="nom" required placeholder="Nombre"></td>
                        <td align="right"><label class="textdir" for="">Apellido</label><input class="inputuser" type="text" value="<?php echo $apellido; ?>" name="apell" id="apell" required placeholder="Apellido"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Calle</label><br><input style="" class="inputuser" type="text" value="<?php echo $calle; ?>" name="calle" id="calle" required placeholder="Calle"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right"><label class="textdir" for="">Ciudad</label><br><input style="width: 200px;" class="inputuser" type="text" value="<?php echo $ciudad; ?>" name="ciudad" id="ciudad" required placeholder="Ciudad"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Pais</label><br><input class="inputuser" type="text" value="<?php echo $pais; ?>" name="pais" id="pais" required placeholder="Pais"></td>
                        <td align="right"><label class="textdir" for="">Departamento</label><br><input style="width: 200px;" class="inputuser" type="text" value="<?php echo $region; ?>" name="dep" id="dep" required placeholder="Depart. o Region"></td>
                    </tr>
                    <tr>
                        <td align="right"><label class="textdir" for="">Codigo Postal</label><br><input style="width: 150px;" class="inputuser" type="number" value=<?php echo $codpostal; ?> name="codpostal" id="codpostal" required placeholder="Codigo"></td>
                        <td align="right"><label class="textdir" for="">Telefono</label><br><input style="width: 150px;" class="inputuser" type="number" value=<?php echo $telef; ?> name="tel" id="tel" required placeholder="Telefono"></td>
                    </tr>
                </table>
        </div>
        <div class="modal-footer">
            <table class="tbluser">
                <tr>
                    <td><input class="btnuser"type="submit" value="Editar" name="edit_direcc"></td>
                    <td><input class="btnuser"type="submit" value="Cancelar" name="cancel"></td>
                </tr>
            </table>
            </form>
        </div>
</article>