<?php
    require("../Model/conexion.php");
    $conexion=Conectar::conexion();
    session_start();
    /*print_r($_GET);

    $clienteid="AVXCUY7wKw7vXQI5fIFthRBK4pZNhbc5cUiPuF2ksFjHOP9HuHt2_aqE6e8h-6uuynuCSaucgt4_SufY";
    $secret="EJge4AspDX3sVrx5zJ2ko43GwlO_iWzRpocvOoPUiK-_MV0VbP2r9mvRKY2LxIwHPVUrN8f9ZxEy_VC-";

    $login=curl_init("https://api.sandbox.paypal.com/v1/oauth2/token");
    curl_setopt($login, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($login, CURLOPT_USERPWD, $clienteid.":".$secret);
    curl_setopt($login, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
    $respuesta=curl_exec($login);
    
    print_r($respuesta);

    $objresult=json_decode($respuesta);*/

    //DATOS DE LA VENTA
    $id_user=$_SESSION["iduser"];
    $id_direcc=$_SESSION["dirselect"];
    $estado="Pendiente";
    //PARAMETROS DE FECHA
    date_default_timezone_set("America/El_Salvador");
    $fecha=date("d-m-Y");
    $total=$_SESSION["totalfinal"];

    //AGREGAR LOS DATOS DE VENTA A LA BD
    $sqlagreventa="INSERT INTO VENTA(ID_USER, ID_DIRECCION, ESTADO, FECHA, TOTAL) VALUES($id_user, $id_direcc, '$estado', '$fecha', $total)";
    $resultagreven=$conexion->prepare($sqlagreventa);
    $resultagreven->execute();
    //BUSCAMOS LA EL ID DE LA ULTIMA VENTA
    $sqlverultiventa="SELECT * FROM VENTA ORDER BY ID_VENTA DESC LIMIT 1";
    $resultverultiventa=$conexion->prepare($sqlverultiventa);
    $resultverultiventa->execute();
    $venta=$resultverultiventa->fetch(PDO::FETCH_ASSOC);
    $id_venta=$venta["id_venta"];



    //DATOS DE DETALLE DE LA VENTA
    foreach($_SESSION["carrito"] as $item){
        $id_product=$item[0];
        $talla=$item[2];
        $cantidad=$item[3];

        $sqlagredetallventa="INSERT INTO DETALLE_VENTA(ID_VENTA, ID_PRODUCT, TALLA, CANTIDAD) VALUE($id_venta, $id_product, '$talla', $cantidad)";
        $resultagredetallventa=$conexion->prepare($sqlagredetallventa);
        $resultagredetallventa->execute();

        if($id_color!=0){
            //RESTAR LAS UNIDADES
            $sqlresuni=$conexion->query("SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO=".$id_product);
            $resunid=$sqlresuni->fetch(PDO::FETCH_ASSOC);
            $resultresunid=$resunid["nunidad"]-$cantidad;
            //ACTUALIZAR LA TABLA DE PRODUCTOS RESTANDO LOS DATOS
            $sqlupproduct="UPDATE PRODUCTOS SET NUNIDAD=$resultresunid WHERE ID_PRODUCTO=".$id_product;
            $ruppro=$conexion->prepare($sqlupproduct);
            $ruppro->execute();
        }else{
            //RESTAR LAS UNIDADES
            $sqlresuni=$conexion->query("SELECT * FROM MUJER WHERE ID_MUJER=".$id_product);
            $resunid=$sqlresuni->fetch(PDO::FETCH_ASSOC);
            $resultresunid=$resunid["nunidad"]-$cantidad;
            //ACTUALIZAR LA TABLA DE PRODUCTOS RESTANDO LOS DATOS
            $sqlupproduct="UPDATE MUJER SET NUNIDAD=$resultresunid WHERE ID_MUJER=".$id_product;
            $ruppro=$conexion->prepare($sqlupproduct);
            $ruppro->execute();
        }

        
    }
    unset($_SESSION["carrito"]);
    unset($_SESSION["totalfinal"]);

    
    echo "<script>location.href='../index.php';</script>";


?>