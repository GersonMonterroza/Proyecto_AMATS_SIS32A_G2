<?php
    class  Direccion{
        private $db;
        private $direccion; 

        public function __construct(){
            require_once("Model/conexion.php");
            $this->db=Conectar::conexion();
            $this->direccion=array();
        }

        public function get_direccion(){
            $sql=$this->db->query("SELECT * FROM DIRECCION");
            while($fila=$sql->fetch(PDO::FETCH_ASSOC)){
                $this->direccion[]=$fila;
            }
            return $this->direccion;
        }
    }
?>