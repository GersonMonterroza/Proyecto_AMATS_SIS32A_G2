<?php
    session_start();

    require("Model/regist_login.php");
    require("Model/agre_direcc.php");
    
    //PARA MOSTRAS LAS DIRECCIONES
    require("Model/get_direcc.php");
    $direccion=new Direccion();
    $arraydirecc=$direccion->get_direccion();

    //PARA MOSTAR PRODUCTOS
    require("Model/get_product.php");
    $product=new Producto();
    $arrayproduct=$product->get_producto();

    //PARA MOSTAR PROMOCIONES
    require("Model/get_mujer.php");
    $promo=new Promo();
    $arraypromo=$promo->get_promo();

    //VER USUARIOS
    require("Model/get_user.php");
    $user=new User();
    $arrayuser=$user->get_user();

    //VER VENTAS
    require("Model/get_venta.php");
    $venta=new Venta();
    $arrayventa=$venta->get_venta();
    
?>

<!--MENU-->
<?php 
    include("View/menu.php"); 

    //BANNER DEL INDEX
    
    if(isset($_GET["pag"])){
        include($_GET["pag"]);
    }else{
?>
<div class="baner">

    <p class="lema-baner">
        Somos tu mejor opción "Calzado Lili"
    </p>
</div>
<!-- CONTENEDOR GENERAL -->
<article class="contenido">
    <!--GALERIA DE CAMISETAS--->
    <?php 
        include("View/galeriacami.php"); 
    ?>
</article>
<?php    
    }
    
    //<!--FOOTER---> 
    include("View/footer.php"); 
?>