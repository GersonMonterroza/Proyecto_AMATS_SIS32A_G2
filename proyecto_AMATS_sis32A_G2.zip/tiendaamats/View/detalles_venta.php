<?php

    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }

    if(isset($_POST["valiestado"])){
        $estad=$_POST["estado"];
        $sqlupventa="UPDATE VENTA SET ESTADO='$estad' WHERE ID_VENTA=".$_GET["id"];
        $resultupventa=$conexion->prepare($sqlupventa);
        $resultupventa->execute();
        
    }

?>
<link rel="stylesheet" href="View/CSS/veruser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <h1 class="tt">Detalles de la Venta</h1><br><br>
        <div class="contensub">
            <div class="venta">
                <div class="detventa">
                    <p>Estado de la venta: </p>
                    <form class="form-estado" method="post">
                        <table class="tbldet">
                            <tr>
                                <td>
                                    <label for="pro">En Proceso:</label>
                                </td>
                                <?php
                                    $sqlventa="SELECT * FROM VENTA WHERE ID_VENTA=".$_GET["id"];
                                    $resultventa=$conexion->prepare($sqlventa);
                                    $resultventa->execute();
                                    $estado=$resultventa->fetch(PDO::FETCH_ASSOC);
                                ?>
                                <td>
                                    <input type="radio" name="estado" id="pro" value="En Proceso" 
                                    <?php
                                        if($estado["estado"]=="En Proceso"){
                                            echo "checked";
                                        }
                                    ?>
                                    >
                                    <label for="pro">
                                        <div class="grey"><div class="selectorestado"><img src="View/IMG/IMG2/check.png" alt="selector"></div></div>
                                    </label>
                                </td>
                                <td>
                                    <label for="en">Enviada:</label>
                                </td>
                                <td>
                                    <input type="radio" name="estado" id="en" value="Enviada" 
                                    <?php
                                        if($estado["estado"]=="Enviada"){
                                            echo "checked";
                                        }
                                    ?>
                                    >
                                    <label for="en">
                                        <div class="grey"><div class="selectorestado"><img src="View/IMG/IMG2/check.png" alt="selector"></div></div>
                                    </label>
                                </td>
                                <td>
                                <button style=" background-color:#44c767;
    -moz-border-radius:20px;
    -webkit-border-radius:20px;
    border-radius:20px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:11px;
    font-style:italic;
    padding:8px 7px;
    text-decoration:none;
    text-shadow:0px 0px 0px #2f6627;" class="btnuser" type="submit" name="valiestado">Cambiar Estado</button>
                                </td>
                            </tr>
                        </table>
                    </form>
                    <table style="background: #dbdbdb;">
                            <tr>
                                <th colspan="6"><h2 class="datousersub">Direccion de Envio</h2></th>
                            </tr>
                            <tr>
                                <td><strong><p>Nombre</p></td>
                                <td><strong><p>Pais</p></td>
                                <td><strong><p>Region</p></td>
                                <td><strong><p>Calle</p></td>
                                <td><strong><p>Cod Postal</p></td>
                                <td><strong><p>Telefono</p></td>
                            </tr>
                            <?php
                                //BUSCAR ID DE LA DIRECCION EN LA TABLA VENTA
                                $sqlverdirenvio="SELECT * FROM VENTA WHERE ID_VENTA=".$_GET["id"];
                                $resultverdirenvio=$conexion->prepare($sqlverdirenvio);
                                $resultverdirenvio->execute();
                                $d=$resultverdirenvio->fetch(PDO::FETCH_ASSOC);
                                //BUSCAR LA DIRECCION EN LA TABLA DIRECCION
                                $sqldirenvio="SELECT * FROM DIRECCION WHERE ID=".$d["id_direccion"];
                                $resultdirenvio=$conexion->prepare($sqldirenvio);
                                $resultdirenvio->execute();
                                $direcc=$resultdirenvio->fetch(PDO::FETCH_ASSOC);
                            ?>
                            <tr>
                                <td><p><?php echo $direcc["nombre"]." ".$direcc["apellido"]; ?></p></td>
                                <td><p><?php echo $direcc["pais"]; ?></p></td>
                                <td><p><?php echo $direcc["region"]; ?></p></td>
                                <td><p><?php echo $direcc["calle"]; ?></p></td>
                                <td><p><?php echo $direcc["codpostal"]; ?></p></td>
                                <td><p><?php echo $direcc["telefono"]; ?></p></td>
                            </tr>
                        </table>
                </div>
                
            <br>
            <table border="0">
                    <tr>
                        <th><h2 class="datousersub">Producto</h2></th>
                        <th><h2 class="datousersub">Talla </h2></th>
                        <th><h2 class="datousersub">Unidades</h2></th>
                    </tr>
                    <?php
                        //VER DATOS DE LA TABLA DETALLE VENTA
                        $sqlverdetallventa="SELECT * FROM DETALLE_VENTA WHERE ID_VENTA=".$_GET["id"];
                        $resultdetalleventa=$conexion->prepare($sqlverdetallventa);
                        $resultdetalleventa->execute();
                        //$detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC);
                        
                        while($detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC)){
                            //VER DATOS DE LA TABLA PRODUCTOS
                            $sqlverproduct="SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO=".$detall_venta["id_product"];
                            $resultverproduct=$conexion->prepare($sqlverproduct);
                            $resultverproduct->execute();
                            $verproduct=$resultverproduct->fetch(PDO::FETCH_ASSOC);
                            
                    ?>

                            <tr>
                                <td>
                                    <?php
                                        //VER DATOS DE LA TABLA PROMOCIONES
                                        $sqlverpromo="SELECT * FROM MUJER WHERE ID_MUJER=".$detall_venta["id_product"];
                                        $resultverpromo=$conexion->prepare($sqlverpromo);
                                        $resultverpromo->execute();
                                        $verpromo=$resultverpromo->fetch(PDO::FETCH_ASSOC);
                                        
                                        if($verpromo!=""){
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verpromo["imagen"]; ?>">

                                    <?php
                                        }else{
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verproduct["imagen"]; ?>">
                                    <?php
                                        }
                                    ?>
                                </td>
                                <td align="center">
                                <section class="pcarri">
                                    <?php
                                        //TALLAS
                                        if($detall_venta["talla"]=="7" or $detall_venta["talla"]=="S"){
                                            echo '<div class="sver"><p>7</p></div>';
                                        }
                                        if($detall_venta["talla"]=="8" or $detall_venta["talla"]=="M" ){
                                            echo '<div class="mver"><p>8</p></div>';
                                        }
                                        if($detall_venta["talla"]=="9" or $detall_venta["talla"]=="L"){
                                            echo '<div class="lver"><p>9</p></div>';
                                        }
                                            
                                        
                                         
                                    ?>
                                </section>
                                </td>
                                <td>
                                    <p><?php echo $detall_venta["cantidad"]; ?></p>
                                </td>
                            </tr>
                    <?php
                            }
                    ?>
                </table>
            </div>
        </div>
</article>