<?php

    $resultproduct=$conexion->query("SELECT * FROM PRODUCTOS");
    $nproductos=$resultproduct->rowCount();
    $ttpro=0;
    while($totalpro=$resultproduct->fetch(PDO::FETCH_ASSOC)){
        $ttpro=$ttpro+$totalpro["nunidad"];
    }

    $resultprom=$conexion->query("SELECT * FROM MUJER");
    $npromo=$resultprom->rowCount();

    $resultuser=$conexion->query("SELECT * FROM USUARIO");
    $nuser=$resultuser->rowCount();

    $resultven=$conexion->query("SELECT * FROM VENTA");
    $nventa=$resultven->rowCount();

?>

<!--ESTILOS CSS PARA ESTA PAGINA-->
    <link rel="stylesheet" href="View/CSS/css_nosotros.css">
    <!--DISEÑOS PARA LOS GRAFICOS-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<script src="View/DiseñosGraficos/js/jquery-1.11.1.min.js"></script>
	<script src="View/DiseñosGraficos/js/bootstrap.min.js"></script>
	<script src="View/DiseñosGraficos/js/chart.min.js"></script>
	<script src="View/DiseñosGraficos/js/chart-data.js"></script>
	<script src="View/DiseñosGraficos/js/easypiechart.js"></script>
	<script src="View/DiseñosGraficos/js/easypiechart-data.js"></script>
	<script src="View/DiseñosGraficos/js/bootstrap-datepicker.js"></script>
	<script src="View/DiseñosGraficos/js/custom.js"></script>
	
<article class="contenido">
<br><br><br><br><br>
<p class="granfttl">Graficos de Datos</p>
<br><br><br><br><br>
<div class="contgrafic"><!--CONTENEDOR DE QUIENES SOMOS-->
    <div class="col-xs-6 col-md-3">
		<div class="granf">
        <p class="titutext">Total registros ingresados</p>
			<div class="panel-body easypiechart-panel">
				<div class="easypiechart" id="easypiechart-teal" data-percent="<?php echo $ttpro?>" ><span class="percent"><?php echo $ttpro?></span></div>
			</div>
		</div>
    </div>
    <!--<div class="col-xs-6 col-md-3">
		<div class="granf">
            <p class="titutext">Total Femenino</p>
			<div class="panel-body easypiechart-panel">
				<div class="easypiechart" id="easypiechart-blue" data-percent="<?php echo $npromo?>" ><span class="percent"><?php echo $npromo?></span></div>
			</div>
		</div>
    </div>-->
    <div class="col-xs-6 col-md-3">
		<div class="granf">
        <p class="titutext">Total de Usuarios</p>
			<div class="panel-body easypiechart-panel">
				<div class="easypiechart" id="easypiechart-red" data-percent="<?php echo $nuser?>" ><span class="percent"><?php echo $nuser?></span></div>
			</div>
		</div>
    </div>
    <div class="col-xs-6 col-md-3">
		<div class="granf">
        <p class="titutext">Total de Ventas</p>
			<div class="panel-body easypiechart-panel">
				<div class="easypiechart" id="easypiechart-orange" data-percent="<?php echo $nventa?>" ><span class="percent"><?php echo $nventa?></span></div>
			</div>
		</div>
    </div>
</div>
</article>
