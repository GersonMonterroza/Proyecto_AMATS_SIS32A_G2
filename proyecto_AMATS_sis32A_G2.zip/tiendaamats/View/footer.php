<footer>
    <img class="img-footer" src="View/IMG/img-baner.png" alt="Imagen de banner">
    <div class="color-footer"></div>

    <section class="seccionesfoo">
        <div class="sesiones">
            <?php
                if(isset($_SESSION["user"])){
                    echo "<a href=index.php?pag=View/datouser.php class=inisesion>" . $_SESSION["user"] . "</a>";
                    echo "<a class=crecuenta href=Model/cerrar.php><p>Cerrar</p></a>";
                }elseif(isset($_SESSION["admin"])){
                    echo "<li style='list-style: none; border-bottom: solid 2px white;' class=inisesion>" . $_SESSION["admin"] . "</li>";
                    echo "<li style='list-style: none; padding-top: 5px;'><a class=crecuenta href=Model/cerrar.php>Cerrar</a></li>";
                }else{
            ?>
            <?php
                }
            ?>
        </div>

        <div class="logo-footer">
            <p class="iniuser" >Todos los derechos reservados</p>
        </div>
    </section>
</footer>