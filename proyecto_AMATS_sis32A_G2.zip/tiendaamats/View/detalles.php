<?php

    if(isset($_POST["carrito"])){
        //VERIFICAR QUE EXISTAN UNIDADES DE PRODUCTOS EN LA BD
        $sqlverunid="SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO=". $_GET["id"];
        $resultverunid=$conexion->prepare($sqlverunid);
        $resultverunid->execute();
        while($verunid=$resultverunid->fetch(PDO::FETCH_ASSOC)){
            $total_unid=$verunid["nunidad"];
        }
#isset($_POST["color"]) and 
        if(isset($_POST["talla"])){
            if($total_unid>$_POST["un"]){
                if(!isset($_SESSION["carrito"])){
                    $carrito[]=array($_GET["id"], $_GET["nombre"],  $_POST["talla"], $_POST["un"], $_GET["precio"], $_GET["imagen"]);
                    $_SESSION["carrito"]=$carrito;
                }else{
                    $_SESSION["carrito"][]=array($_GET["id"], $_GET["nombre"],  $_POST["talla"], $_POST["un"], $_GET["precio"], $_GET["imagen"]);
                }
                echo "<script>
                    $(function(){
                        alertify.success('Producto agregado al Carrito.');
                    });
                </script>";
            }else{ 
                echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>No hay suficiente Producto.');
                        });
                    </script>";
            }
        }else{
            echo "<script>
                        $(function(){
                            alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Debes seleccionar una talla.');
                        });
                    </script>";
        }
    }

?>
    <!--LINKS DE ESTILOS CSS3-->
    <link rel="stylesheet" href="View/CSS/css_detalles_camisas.css">

    <article class="contenido"><!-- CONTENEDOR GENERAL -->
        <form class="form-color form-talla" action="" method="post">
        <div class="camiseta"><!--CONTENEDOR DE CAMISETA-->
            <img id="camiseta" src="View/IMGsubido/<?php echo $_GET["imagen"]; ?>" alt="Camiseta akatsuki">
        </div>

        <!--CONTENEDOR DE DETALLES CAMISETA-->
        <div class="detacamisa">
            <p class="titulocamiseta"><?php echo $_GET["nombre"]; ?></p>

           

            <!--______________OPCIONES DE TALLAS__________________________________________________________________-->
            <p class="subdetalles">Tallas disponibles:</p>
           
                <section class="tallas">
                <?php
                    $sqltalla=$conexion->query("SELECT * FROM TALLAPRODUCT WHERE ID_PRODUCTO=". $_GET["id"]);
                    while($filatalla=$sqltalla->fetch(PDO::FETCH_ASSOC)){
                        if($filatalla["id_talla"]==1){
                            echo '
                            <input type="radio" name="talla" id="s" value=S>
                            <label for="s">
                                <div class="s"><p>7</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                            </label>
                            ';
                        }
                        if($filatalla["id_talla"]==2){
                            echo '
                            <input type="radio" name="talla" id="m" value=M>
                            <label for="m">
                                <div class="m"><p>8</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                            </label>
                            ';
                        }
                        if($filatalla["id_talla"]==3){
                            echo '
                            <input type="radio" name="talla" id="" value=L>
                            <label for="l">
                                <div class="l"><p>9</p><div class="selectorcami"><img src="View/IMG/IMG2/selector.png" alt="selector"></div></div>
                            </label>
                            ';
                        }
                        
                    }
                ?>    
                </section>
            

            <!--______________MAS DETALLES__________________________________________________________________-->
            <p class="subdetalles">Mas detalles:</p>
            <section class="masdeta">
                <p><?php echo $_GET["detalle"]; ?></p>
            </section>

            <!--______________UNIDADES__________________________________________________________________-->
            <p class="subdetalles">Unidades</p>
            <section class="unidades">
                    <select name="un" id="un">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
            </section>

            <!--______________PRECIOS__________________________________________________________________-->
            <p class="acepprecio">Precio</p> <br>
            <p class="pre">$ <?php echo $_GET["precio"]; ?></p>

            <!--______________BOTON DE OBTENER__________________________________________________________________-->
            <section class="precio">
                <button style="    background-color:#44c767;
    -moz-border-radius:28px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Verdana;
    font-size:17px;
    font-style:italic;
    padding:16px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;" name="carrito">
                    <p>Adquirir</p>
                    <img src="View/IMG/IMG2/carrito-blanco.png" >
                </button>
            </section>
        </div>
        </form>
    </article>