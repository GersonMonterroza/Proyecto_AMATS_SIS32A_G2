<header>
    <nav>
        <a href="index.php"><img class="img-logo" src="View/IMG/IMG2/urban1.png"></a>
        <ul class="menu">
            <?php
                //VALIDAR LOS NIVELES DE USUARIOS 
                if(isset($_SESSION["admin"])){
            ?>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="Model/agre_product.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=Model/agre_product.php">Masculinos</a></li>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="Model/agre_mujer.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=Model/agre_mujer.php">Femeninos</a></li>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="Model/veruser.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=View/veruser.php">Usuarios</a></li>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="Model/veruser.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=View/ventas.php">Ventas</a></li>
            <?php
                }else{
            ?>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="index.php"){ echo 'class="selec"';  } } ?> href="index.php">Masculinos</a></li>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="View/mujer.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=View/mujer.php">Femeninos</a></li>
                    <li><a <?php if(isset($_GET["pag"])){ if($_GET["pag"]=="View/nosotros.php"){ echo 'class="selec"';  } } ?> href="index.php?pag=View/nosotros.php">Nosotros</a></li>
            <?php
                }
            ?>
        </ul>
        <ul class="user">
            <?php
                if(isset($_SESSION["user"])){
                    echo "<li><a href=index.php?pag=View/datouser.php>" . $_SESSION["user"] . "</a></li>";
                    echo "<li><a href=Model/cerrar.php>Cerrar</a></li>";
                    echo '</ul>
                    <a href="index.php?pag=View/carrito.php"><img class="img-carrito" src="View/IMG/IMG2/carrito-blanco.png"></a>';
                }elseif(isset($_SESSION["admin"])){
                    //echo "<li><a href=index.php?pag=View/datouser.php>" . $_SESSION["admin"] . "</a></li>";
                    //echo "<li><a href=Model/cerrar.php>Cerrar</a></li>";
                }else{
            ?>
            <li><a href="#login" data-toggle="modal">Iniciar Sesion</a></li>
            <li><a href="#registrarse" data-toggle="modal">Registrarse</a></li>
            
        </ul>
        <a href="index.php?pag=View/carrito.php"><img class="img-carrito" src="View/IMG/IMG2/carrito-blanco.png"></a>
        <?php
                }
            ?>
    </nav>
</header>