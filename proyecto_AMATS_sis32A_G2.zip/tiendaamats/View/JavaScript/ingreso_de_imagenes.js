function comenzar(){
    var archivos=document.getElementById("archivos");
    zonaedit=document.getElementById("zonaedit");
    archivos.addEventListener("change", procesar, false);
}

function procesar(e){
    var archivos=e.target.files;
    zonaedit.innerHTML="";
    var mi_archivo=archivos[0];
    //PARA COMPROBAR SI ES UNA IMAGEN 
    if(!mi_archivo.type.match(/image/)){
        alert("SELECCIONE UNA IMAGEN PORFAVOR!!!")
    }else{
        var lector=new FileReader();
        lector.readAsDataURL(mi_archivo);
        lector.addEventListener("load", mostrar, false);
    }
}

function mostrar(e){
    var resultado=e.target.result;
    zonaedit.innerHTML+="<img class='iedit' src='" + resultado + "'>";
}


window.addEventListener("load", comenzar, false);