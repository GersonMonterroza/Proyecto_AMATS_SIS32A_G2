<?php

    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }


?>
<link rel="stylesheet" href="View/CSS/datouser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <h1 class="tt">Compras Realizadas por el <br> Usuario </h1>
        <div class="contensub">
            <h2 class="datousersub">Historial de Compras</h2>
            <div class="venta">
                <table border="0">
                    <tr>
                        <th><h2 class="datousersub">Producto</h2></th>
                        <th><h2 class="datousersub">Talla</h2></th>
                        <th><h2 class="datousersub">Unidades</h2></th>
                        <th><h2 class="datousersub">Fecha de Compra</h2></th>
                    </tr>
                <?php $totalven=0;  foreach($arrayventa as $idven=>$venta): ?>
                
                    <?php
                        
                        if($venta["id_user"]==$_GET["id"]){
                            $totalven++;
                            //VER DATOS DE LA TABLA DETALLE VENTA
                            $sqlverdetallventa="SELECT * FROM DETALLE_VENTA WHERE ID_VENTA=".$venta["id_venta"];
                            $resultdetalleventa=$conexion->prepare($sqlverdetallventa);
                            $resultdetalleventa->execute();
                            //$detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC);
                            
                            while($detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC)){
                                //VER DATOS DE LA TABLA PRODUCTOS
                                $sqlverproduct="SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO=".$detall_venta["id_product"];
                                $resultverproduct=$conexion->prepare($sqlverproduct);
                                $resultverproduct->execute();
                                $verproduct=$resultverproduct->fetch(PDO::FETCH_ASSOC); 
                    ?>

                            <tr <?php if($idven%2==0){ echo "class=colortr"; } ?>>
                                <td>
                                    <?php
                                        //VER DATOS DE LA TABLA PROMOCIONES
                                        $sqlverpromo="SELECT * FROM MUJER WHERE ID_MUJER=".$detall_venta["id_product"];
                                        $resultverpromo=$conexion->prepare($sqlverpromo);
                                        $resultverpromo->execute();
                                        $verpromo=$resultverpromo->fetch(PDO::FETCH_ASSOC);
                                        if($verpromo!=""){
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verpromo["imagen"]; ?>">

                                    <?php
                                        }else{
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verproduct["imagen"]; ?>">
                                    <?php
                                        }
                                    ?>
                                </td>
                                <td align="center">
                                <section class="pcarri">
                                    <?php
                                        
                                        //TALLAS
                                        if($detall_venta["talla"]=="7" or $detall_venta["talla"]=="S" ){
                                            echo '<div class="sver"><p>7</p></div>';
                                        }
                                        if($detall_venta["talla"]=="8" or $detall_venta["talla"]=="M"){
                                            echo '<div class="mver"><p>8</p></div>';
                                        }
                                        if($detall_venta["talla"]=="9" or $detall_venta["talla"]=="" ){
                                            echo '<div class="lver"><p>9</p></div>';
                                        }
                                    ?>
                                </section>
                                </td>
                                <td>
                                    <p><?php echo $detall_venta["cantidad"]; ?></p>
                                </td>
                                <td>
                                    <p><?php echo $venta["fecha"]; ?></p>
                                </td>
                            </tr>
                    <?php
                            }
                            echo '<tr class=ttalfinal>
                                    <td></td>
                                    <td></td>
                                    <td colspan="2"><p>Total de la venta: $ '.$venta["total"].'</p></td>

                                </tr> '; 
                        }
                    ?>

                <?php endforeach; ?>
                </table>
            </div>
            <h2 class="datousersub">Total de compras Realizadas: <?php echo $totalven; ?></h2>
        </div>
</article>
