<?php

    if(isset($_POST["carrito"])){
        if(!isset($_SESSION["user"])){
            echo "<script>
                    $(function(){
                        alertify.warning('<img width=50 src=View/IMG/IMG2/warning.png><br>Debes iniciar sesion o registrarte para seguir con la compra!!!.');
                    });
                </script>";
        }else{
            echo "<script>location.href='index.php?pag=Model/proceso_direcc.php';</script>";
        }
    } 

?>
<link rel="stylesheet" href="View/CSS/carrito.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
    <form class="form-color" method="post">
        <h1 class="tt">Tu Carrito</h1><br><br>
        <div class="contensub">
            <br>
            <?php
                if(!isset($_SESSION["carrito"])){
                    echo "<br><br><p style='text-align: center; font-size: 2.5em;'>No hay Productos en el Carrito.!!!</p>";
                }else{
            ?>
            <table border="1">
                <tr>
                    <th><h2 class="datousersub">Producto</h2></th>
                    <th><h2 class="datousersub">Talla </h2></th>
                    <th><h2 class="datousersub">Unidades</h2></th>
                    <th><h2 class="datousersub">Precio</h2></th>
                    <th><h2 class="datousersub">Total</h2></th>
                    <th></th>
                </tr>
                <?php 
                    $totalfinal=0;
                    $totalproduct=0;
                    foreach($_SESSION["carrito"] as $i=>$product):
                        $unidades=$product["3"];
                        $precio=(float)$product["4"];
                        $totalpre=$unidades*$precio;
                        $totalproduct=$totalproduct+$product["3"];
                        $_SESSION["totalproduct"]=$totalproduct;
                    
                    ?>
                    
                    <tr <?php if($i%2==0){ echo "class=colortr"; } ?>>
                        <td class="imgcarri"><img width="70" height=80 src="View/IMGsubido/<?php echo $product[5]; ?>"><p><?php echo $product[1]; ?></p></td>
                        <td><section class="pcarri">
                            <?php
                                
                                //TALLAS
                                if($product["2"]=="S"){
                                    echo '<div class="sver"><p>7</p></div>';
                                }
                                if($product["2"]=="M"){
                                    echo '<div class="mver"><p>8</p></div>';
                                }
                                if($product["2"]=="L"){
                                    echo '<div class="lver"><p>9</p></div>';
                                }
                                
                            ?>
                        </section></td>
                        <td><p class="pcarri"><?php echo $product["3"]; ?></p></td>
                        <td><p class="pcarri">$<?php echo $product["4"]; ?></p></td>
                        <td><p class="pcarri">$<?php echo $totalpre; ?></p></td>
                        <td><a class="" href="index.php?pag=View/eliproductcarrito.php & idcarri=<?php echo $i;?>"><img class="btnagregar" src="View/IMG/IMG2/borrarcarri.png" alt=""></a></td>
                        
                    </tr>
                <?php
                    $totalfinal=$totalfinal+$totalpre;
                    $_SESSION["totalfinal"]=$totalfinal;
                ?>
                    <!--<input type="hidden" name="idproduct[]" value="<?php //echo $product["0"]; ?>">
                    <input type="hidden" name="nombre[]" value="<?php //echo $product["1"]; ?>">
                    <input type="hidden" name="talla[]" value="<?php //echo $product["3"]; ?>">
                    <input type="hidden" name="unidad[]" value="<?php //echo $product["4"]; ?>">
                    <input type="hidden" name="precio[]" value="<?php //echo$product["5"]; ?>">
                    <input type="hidden" name="totalpagar[]" value="<?php //echo $totalfinal; ?>">-->
                <?php
                    endforeach;
                ?>
                <th class="ttlcarri"><h2></h2></th>
                <th class="ttlcarri"><h2></h2></th>
                <th class="ttlcarri"><h2></h2></th>
                <th class="ttlcarri" colspan="2"><h2>Total a Pagar $<?php echo $totalfinal; ?></h2></th>
                <th class="ttlcarri"><h2></h2></th>
                <th class="ttlcarri"></th>
                <tr>
                    <th class="ttlcarri"><h2></h2></th>
                    <th class="ttlcarri"><h2></h2></th>
                    <th class="ttlcarri"><h2></h2></th>
                    
                    <th class="ttlcarri" colspan="3"><h2>
                        <button style=" background-color:#44c767;
    -moz-border-radius:20px;
    -webkit-border-radius:20px;
    border-radius:20px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:10px;
    font-style:italic;
    padding:8px 7px;
    text-decoration:none;
    text-shadow:0px 0px 0px #2f6627;" name="carrito">
                            <p>Sigue para Pagar</p>
                            <!--<img src="View/IMG/IMG2/paypal.png" alt="Carrito de Compras">-->
                        </button>
                    </h2></th>
                    <th class="ttlcarri"><h2></h2></th>
                    <th class="ttlcarri"></th>
                </tr>
            </table>
                <?php } ?>
        </div>
    </form>    
</article>

