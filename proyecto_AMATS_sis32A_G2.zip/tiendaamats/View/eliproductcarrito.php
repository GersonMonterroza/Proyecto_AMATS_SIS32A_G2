<?php

    unset($_SESSION["carrito"][$_GET["idcarri"]]);
    echo "<script>location.href='index.php?pag=view/carrito.php';</script>";

?>