<?php

    if(!isset($_SESSION["admin"])){
        echo "<script>location.href='index.php';</script>";
    }

?>
<link rel="stylesheet" href="View/CSS/veruser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <h1 class="tt">Ventas</h1><br><br>
        <div class="contensub">
            <?php 
                $n=count($arrayventa);
                echo "<p>Total de Ventas Registradas: " . $n . "</p>";
            ?>
            <br>
            <table border="1">
                <tr>
                    <th align="left"><h2 class="datousersub">Usuario</h2></th>
                    <th colspan="" align="left"><h2 class="datousersub">Estado</h2></th>
                    <th colspan="" align="left"><h2 class="datousersub">Total</h2></th>
                    <th colspan="" align="left"><h2 class="datousersub"></h2></th>
                </tr>
                <?php foreach($arrayventa as $i=>$verventa): ?>
                    <?php
                            $sqlveruser="SELECT * FROM USUARIO WHERE ID=".$verventa["id_user"];
                            $resultveruser=$conexion->prepare($sqlveruser);
                            $resultveruser->execute();
                            $user=$resultveruser->fetch(PDO::FETCH_ASSOC);
                            
                    ?>
                    <tr <?php if($i%2==0){ echo "class=colortr"; } ?>>
                        <td><p><?php echo $user["nombre"]." ".$user["apellido"]; ?></p></td>
                        <td><p><?php echo $verventa["estado"]; ?></p></td>
                        <td><p>$ <?php echo $verventa["total"]; ?></p></td>
                        <td><a href="index.php?pag=View/detalles_venta.php & id=<?php echo $verventa["id_venta"]; ?>"><button style="background-color:#44c767;
    -moz-border-radius:10px;
    -webkit-border-radius:28px;
    border-radius:28px;
    border:1px solid #18ab29;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:17px;
    font-style:italic;
    padding:auto;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
    float: right;" type="button">Detalles</button></a></td>

                    </tr>
                   
                <?php endforeach; ?>

            </table>
        </div>
</article>

