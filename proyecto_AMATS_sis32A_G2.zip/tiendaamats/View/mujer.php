<link rel="stylesheet" href="View/CSS/css_promocion.css">
    <!--GALERIA DE CAMISETAS_____________________________________________________________________-->
    <article class="contenido"><!-- CONTENEDOR GENERAL -->
        <div class="conten1">
            <?php foreach($arraypromo as $prom): ?>
            <section class="descri-camisprom">
                <a style="text-decoration: none;" href="index.php?pag=View/detalles_mujer.php & id=<?php echo $prom["id_mujer"]; ?> & nombre=<?php echo $prom["nombre"]; ?> & detalle=<?php echo $prom["detalle"]; ?> & nunidad=<?php echo $prom["nunidad"]; ?> & precio=<?php echo $prom["precio"]; ?> & imagen=<?php echo $prom["imagen"]; ?> ">
                    <img class="camisetasprom" src="View/IMGsubido/<?php echo $prom["imagen"]; ?>">
                    <p class="desprom"><?php echo $prom["nombre"]; ?></p>
                    <section class="descricprom">
                        <p><?php echo $prom["precio"]; ?> USD</p>
                        <p>Tallas</p>
                        <p>
                        <?php
                            $sqltallapro=$conexion->query("SELECT * FROM TALLAMUJER WHERE ID_MUJER=". $prom["id_mujer"]);
                            while($filatallapro=$sqltallapro->fetch(PDO::FETCH_ASSOC)){
                                if($filatallapro["id_talla"]==1){
                                    echo '7 ';
                                }
                                if($filatallapro["id_talla"]==2){
                                    echo '8 ';
                                }
                                if($filatallapro["id_talla"]==3){
                                    echo '9 ';
                                }
                            }
                        ?>
                        </p> 
                    </section>
                </a>
            </section>
            <?php endforeach; ?>
        </div>
    </article>
  