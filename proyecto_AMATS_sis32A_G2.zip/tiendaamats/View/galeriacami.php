<?php

    //DATOS PARA LA PAGINACION
    $tamaño_pag=9;

    if(isset($_GET["pagina"])){
        if($_GET["pagina"]==1){
            $pag=$_GET["pagina"];
        }else{
            $pag=$_GET["pagina"];
        }
    }else{
        $pag=1;
    }

    $desde=($pag-1)*$tamaño_pag;

    //CONTAR EL TOTAL DE LOS ARTICULOS
    $resultcount=$conexion->prepare("SELECT * FROM PRODUCTOS");
    $resultcount->execute();
    $num_art=$resultcount->rowCount();
    $total_pag=ceil($num_art/$tamaño_pag);

    $resultcount->closecursor();

    $resultlimit=$conexion->prepare("SELECT * FROM PRODUCTOS ORDER BY ID_PRODUCTO DESC LIMIT  $desde,$tamaño_pag");
    $resultlimit->execute();
?>
<article class="contenido"><!-- CONTENEDOR GENERAL -->
<div class="conten">
<?php foreach($resultlimit as $product): ?>
    <section class="descri-camis">
        <a style="text-decoration: none;" href="index.php?pag=View/detalles.php & id=<?php echo $product["id_producto"]; ?> & nombre=<?php echo $product["nombre"]; ?> & detalle=<?php echo $product["detalle"]; ?> & nunidad=<?php echo $product["nunidad"]; ?> & precio=<?php echo $product["precio"]; ?> & imagen=<?php echo $product["imagen"]; ?> ">
            <img class="camisetas" src="View/IMGsubido/<?php echo $product["imagen"]; ?>">
            <p class="des"><?php echo $product["nombre"]; ?></p>
            <section class="descric">
                <p><?php echo $product["precio"]; ?> USD</p>
                <p>Tallas</p>
                <p>
                <?php
                    $sqltalla=$conexion->query("SELECT * FROM TALLAPRODUCT WHERE ID_PRODUCTO=". $product["id_producto"]);
                    while($filatalla=$sqltalla->fetch(PDO::FETCH_ASSOC)){
                        if($filatalla["id_talla"]==1){
                            echo '7 ';
                        }
                        if($filatalla["id_talla"]==2){
                            echo '8';
                        }
                        if($filatalla["id_talla"]==3){
                            echo '9';
                        }
                        
                    }
                ?>
                </p>
            </section>
        </a>
    </section>
<?php endforeach; ?>
</div>
</article>
<?php
    //PAGINACION
    echo "<div class='pag'>";
    //REGRESAR PAGINA
    if($pag>1){
        echo " <a class='num flaticon-left-arrow' href='?pagina=" . ($pag-1) . "'></a>  ";
    }
    //NUMERO DE PAGINAS
?>

    <?php for($i=1; $i<=$total_pag; $i++): ?>
        <article class="num1 <?php echo $pag==$i ? 'active' : ''; ?>">
            <a class="num" href="?pagina=<?php echo $i ?>"> <?php echo $i ?> </a>
        </article>
    <?php endfor ?>

<?php
    //ADELANTAR PAGINA 
    if($pag<$total_pag){
        echo " <a class='num flaticon-right-arrow' href='?pagina=" . ($pag+1) . "'></a>  ";
    }
    echo "</div>"
?>
<!--ESTILOS DE PAGINACION-->
<style>
    a{
        text-decoration: none;
    }
    .pag{
        float: bottom;
        width: 30%;
        text-align: center;
        padding: 2px 0px 2px 0px;
        font-size: 1.5em;
        margin: auto;
        margin-top: 20px;
        border-radius: 25px;
    }
    .num{
        text-decoration: none;
        font-family: "arials";
        text-align: center;
        color: black;
    }
    .num1{
        display:inline-block;
        padding: 0px 5px 0px 5px;
        margin: 1px;
        border-radius: 50px;
        text-align: center;
    }
    .active{
        background-color: white;
        color: white;
        border: solid 1px #070044d7;
    
    }
    .contenido{
        background-color: #BCFEB5;
    }
</style>


