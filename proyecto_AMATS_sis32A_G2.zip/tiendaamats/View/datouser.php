<?php

    if(!isset($_SESSION["user"])){
        echo "<script>location.href='index.php';</script>";
    }


?>
<link rel="stylesheet" href="View/CSS/datouser.css">
<article class="contenido"><!-- CONTENEDOR GENERAL -->
        <h1 class="tt">Cuenta</h1>
        <h1 class="datouser icono flaticon-user"><?php echo $_SESSION["user"]; ?></h1>
        <div class="contensub">
            <h2 class="datousersub">Historial de Compras</h2>
            <div class="venta">
                <table border="0">
                    <tr>
                        <th><h2 class="datousersub">Producto</h2></th>
                        <th><h2 class="datousersub">Talla </h2></th>
                        <th><h2 class="datousersub">Unidades</h2></th>
                        <th><h2 class="datousersub">Fecha de Compra</h2></th>
                    </tr>
                <?php foreach($arrayventa as $idven=>$venta): ?>
                
                    <?php
                    
                        if($venta["id_user"]==$_SESSION["iduser"]){
                            //VER DATOS DE LA TABLA DETALLE VENTA
                            $sqlverdetallventa="SELECT * FROM DETALLE_VENTA WHERE ID_VENTA=".$venta["id_venta"];
                            $resultdetalleventa=$conexion->prepare($sqlverdetallventa);
                            $resultdetalleventa->execute();
                            //$detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC);
                            
                            while($detall_venta=$resultdetalleventa->fetch(PDO::FETCH_ASSOC)){
                                //VER DATOS DE LA TABLA PRODUCTOS
                                $sqlverproduct="SELECT * FROM PRODUCTOS WHERE ID_PRODUCTO=".$detall_venta["id_product"];
                                $resultverproduct=$conexion->prepare($sqlverproduct);
                                $resultverproduct->execute();
                                $verproduct=$resultverproduct->fetch(PDO::FETCH_ASSOC);
                    ?>

                            <tr <?php if($idven%2==0){ echo "class=colortr"; } ?>>
                                <td>
                                    <?php
                                        //VER DATOS DE LA TABLA PROMOCIONES
                                        $sqlverpromo="SELECT * FROM MUJER WHERE ID_MUJER=".$detall_venta["id_product"];
                                        $resultverpromo=$conexion->prepare($sqlverpromo);
                                        $resultverpromo->execute();
                                        $verpromo=$resultverpromo->fetch(PDO::FETCH_ASSOC);
                                        if($detall_venta["color"]==0){
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verpromo["imagen"]; ?>">

                                    <?php
                                        }else{
                                    ?>
                                            <img width="70" height=80 src="View/IMGsubido/<?php echo $verproduct["imagen"]; ?>">
                                    <?php
                                        }
                                    ?>
                                </td>
                                <td align="center">
                                <!--<section class="pcarri">-->
                                    <?php
                                        
                                        //TALLAS
                                        if($detall_venta["talla"]=="7" or $detall_venta["talla"]=="S" ){
                                            echo '<div class="sver"><p>7</p></div>';
                                        }
                                        if($detall_venta["talla"]=="8" or $detall_venta["talla"]=="M"){
                                            echo '<div class="mver"><p>8</p></div>';
                                        }
                                        if($detall_venta["talla"]=="9" or $detall_venta["talla"]=="L"){
                                            echo '<div class="lver"><p>9</p></div>';
                                        }
                                    ?>
                                <!--</section>-->
                                </td>
                                <td>
                                    <p><?php echo $detall_venta["cantidad"]; ?></p>
                                </td>
                                <td>
                                    <p><?php echo $venta["fecha"]; ?></p>
                                </td>
                            </tr>
                    <?php
                            }
                            echo '<tr class=ttalfinal>
                                    <td></td>
                                    <td></td>
                                    <td colspan="2"><p>Total de la venta: $ '.$venta["total"].'</p></td>

                                </tr> '; 
                        }
                    ?>

                <?php endforeach; ?>
                </table>
            </div>
        </div>
        <div class="contensub" style="margin-top: 70px;">
            <h2 class="datousersub">Direcciones</h2>
            <!--BOTON PARA INGRESAR DIRECCION-->
            <button class="btnuser" style="width: 200px; height: 40px; float: right; margin-top: -40px;" type="button" href="#direcc" data-toggle="modal">Agregar Direccion</button>
             <!--FORMULARIO PARA INGRESAR DIRECCION-->
             <div class="direcc">
            <?php foreach($arraydirecc as $direcc): ?>
                <?php
                    $verdir=$conexion->query("SELECT * FROM USERDIRECC WHERE ID_USER=".$_SESSION["iduser"]);
                    while($veruserdir=$verdir->fetch(PDO::FETCH_ASSOC)){
                        if($direcc["id"]==$veruserdir["id_direcc"]){
                ?>
                            <div>
                                <h3 class="ttdir"><?php echo $direcc["nombre"] . " " . $direcc["apellido"] ?></h3>
                                    <h4 class="dtdir"><?php echo $direcc["calle"] ?></h4>
                                    <h4 class="dtdir"><?php echo $direcc["ciudad"] ?></h4>
                                    <h4 class="dtdir"><?php echo $direcc["region"] ?></h4>
                                    <h4 class="dtdir"><?php echo $direcc["codpostal"] ?></h4>
                                    <h4 class="dtdir"><?php echo $direcc["pais"] ?></h4>
                                    <button class="btnuser" style="width: 100px; height: 35px; float: left;"><a style="text-decoration: none; color: #070044c5" href="index.php?pag=Model/edit_direcc.php & id=<?php echo $direcc["id"] ?> & nom=<?php echo $direcc["nombre"] ?> & apell=<?php echo $direcc["apellido"] ?> & calle=<?php echo $direcc["calle"] ?> & ciudad=<?php echo $direcc["ciudad"] ?> & pais=<?php echo $direcc["pais"] ?> & region=<?php echo $direcc["region"] ?> & codpostal=<?php echo $direcc["codpostal"] ?> & tel=<?php echo $direcc["telefono"] ?>">Editar</a></button>
                                    <button class="btnuser" style="width: 100px; height: 35px; float: right"><a style="text-decoration: none; color: #070044c5" href="index.php?pag=Model/elim_direcc.php & id=<?php echo $direcc["id"] ?> ">Borrar</a></button>
                            </div>
               <?php
                        }
                    }
               ?>
            <?php endforeach; ?>
             </div>
        </div>
</article>
