<!--ESTILOS CSS PARA ESTA PAGINA-->
<link rel="stylesheet" href="View/CSS/css_nosotros.css">
<article class="contenido">
<div class="somos"><!--CONTENEDOR DE QUIENES SOMOS-->
    <section>
        <p class="titutext">Quienes Somos</p>
        <p class="infotext">
            Somos una empresa distribuidora de calzados para hombres y mujeres donde damos lo mejor para servirle a usted.
        </p>
    </section>
</div>
<div class="valor"><!--DISEÑO DE LOS VALORES-->
    <section>
        <p class="titutext">Misión</p>
        <p class="infotext">
            Dar lo mejor a nuestros clientes para se sientan comodos y alegres en su compras de calzado, pero a la vez brindarle el mejor momento de compras.
        </p>
    </section>
    <section>
        <p class="titutext">Visión</p>
        <p class="infotext">
            Dar lo mejor en el establecimineto donde estamos ubicados y despues llegar a ser una de los mayores distrubuidores de calzado en el salvador.
        </p>
    </section>
</div>
</article>
