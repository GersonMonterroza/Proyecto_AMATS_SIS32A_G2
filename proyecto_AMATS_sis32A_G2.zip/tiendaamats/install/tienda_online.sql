-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-06-2019 a las 14:22:58
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_online`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `id_detallventa` int(11) NOT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `id_product` int(11) DEFAULT NULL,
  `talla` varchar(1) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalle_venta`
--

INSERT INTO `detalle_venta` (`id_detallventa`, `id_venta`, `id_product`, `talla`, `cantidad`) VALUES
(13, 6, 12, 'S', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE `direccion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `apellido` varchar(35) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `region` varchar(50) NOT NULL,
  `codpostal` varchar(10) NOT NULL,
  `telefono` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`id`, `nombre`, `apellido`, `calle`, `ciudad`, `pais`, `region`, `codpostal`, `telefono`) VALUES
(3, 'Bryan ', 'Hernandez', 'santa ana', 'santa ana', 'El salvador', 'Santa ana ', '1234', 77770000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mujer`
--

CREATE TABLE `mujer` (
  `id_mujer` int(11) NOT NULL,
  `nombre` varchar(75) NOT NULL,
  `detalle` varchar(250) NOT NULL,
  `nunidad` int(11) NOT NULL,
  `precio` float NOT NULL,
  `imagen` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mujer`
--

INSERT INTO `mujer` (`id_mujer`, `nombre`, `detalle`, `nunidad`, `precio`, `imagen`) VALUES
(3, 'zapato femenino', 'Zapato semicasual azul', 12, 7, 'm1.jpg'),
(4, 'Tenis Femeninos', 'Zapatos Nike femeninos, ideales para todas las deportistas', 20, 50, 'm2.jpg'),
(5, 'Zapatilla ', 'Zapatilla super comoda, ideal para descanzar el pie', 15, 10, 'm3.jpg'),
(6, 'Tenis rosa', 'Tenis rosa, ideal para todas las mujeres que les gusta lucir su lado femenino', 20, 50, 'm4.jpg'),
(7, 'Tenis Azules', 'tenis super comodos y a la moda', 30, 20, 'm5.jpg'),
(8, 'Tenis Willson', 'ideales para las amantes del deporte ', 20, 40, 'm6.jpg'),
(9, 'Botines de cuero', 'Botines de cuero genuino, super resistentes', 30, 20, 'm7.jpg'),
(10, 'zapatilla casual', 'Zapatilla color rosa, ideal para personas amantes de lo esencial', 15, 20, 'm8.jpg'),
(11, 'Zapatilla semicasual', 'ideal para las personas que les gusta lucir bien, sin dejar de lado la comodidad', 20, 12, 'm9.jpg'),
(12, 'zapatos de charol rosa', 'Zapatos ordinarios de charol, color rosa, ideales para lucir explendida.', 10, 40, 'm10.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(35) DEFAULT NULL,
  `detalle` varchar(250) DEFAULT NULL,
  `nunidad` int(11) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `imagen` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `detalle`, `nunidad`, `precio`, `imagen`) VALUES
(14, 'Zapato deportivo', 'Zapato deportivo, ideal para las personas amantes del deporte y de cuidar su cuerpo', 20, 30, '1.jpg'),
(15, 'Zapato deportivo New Balance', 'Zapatos marca New Balance, garantizada la comodidad para su pie...', 20, 40, '2.jpg'),
(16, 'Rebook tenis', '¡Bonitos, buenos y baratos!', 20, 35, '3.jpg'),
(17, 'Zapato semicasual', 'Ideal para las personas amantes de la simplicidad.', 10, 20, '4.jpg'),
(18, 'Zapatos casuales cafe', 'Zapatos causales, ideales para vestir en dias de primavera', 11, 25, '5.jpg'),
(19, 'Zapatos Burros', 'Zapatos resistentes a todo tipo de ambiente y suelo ', 15, 22, '6.jpg'),
(20, 'Zapato de vestir  ', 'ideal para toda clase de ocasiones formales  ', 20, 15, '7.jpg '),
(21, 'zapato mascuino', 'Zapato de lamarca CAT, muy reisistente y de cuero genuino ', 20, 50, '8.jpg'),
(22, 'zapatos de Charol hombre ', 'Zapatos de charol, ideales para eventos formales o de su preferencia  ', 12, 14, '9.jpg '),
(23, 'Zapatos casuales ', 'ideales para toda hombres de verdad', 18, 20, '10.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prueba`
--

CREATE TABLE `prueba` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `categoria` varchar(35) NOT NULL,
  `precio` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talla`
--

CREATE TABLE `talla` (
  `id_talla` int(11) NOT NULL,
  `talla` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `talla`
--

INSERT INTO `talla` (`id_talla`, `talla`) VALUES
(1, 7),
(2, 8),
(3, 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tallamujer`
--

CREATE TABLE `tallamujer` (
  `id_talmujer` int(11) NOT NULL,
  `id_mujer` int(11) DEFAULT NULL,
  `id_talla` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tallamujer`
--

INSERT INTO `tallamujer` (`id_talmujer`, `id_mujer`, `id_talla`) VALUES
(6, 3, 1),
(7, 3, 2),
(8, 4, 1),
(9, 4, 2),
(10, 5, 1),
(11, 5, 2),
(12, 5, 3),
(13, 6, 1),
(14, 6, 3),
(15, 7, 2),
(16, 7, 3),
(17, 8, 1),
(18, 8, 2),
(19, 8, 3),
(20, 9, 1),
(21, 9, 2),
(22, 10, 1),
(23, 10, 3),
(24, 11, 1),
(25, 11, 2),
(26, 11, 3),
(27, 12, 1),
(28, 12, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tallaproduct`
--

CREATE TABLE `tallaproduct` (
  `id_tapro` int(11) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `id_talla` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tallaproduct`
--

INSERT INTO `tallaproduct` (`id_tapro`, `id_producto`, `id_talla`) VALUES
(29, 14, 1),
(30, 14, 2),
(31, 14, 3),
(32, 15, 1),
(33, 15, 2),
(34, 16, 1),
(35, 16, 2),
(36, 16, 3),
(37, 17, 1),
(38, 18, 1),
(39, 18, 2),
(40, 18, 3),
(41, 19, 1),
(42, 19, 3),
(48, 21, 1),
(47, 20, 2),
(46, 20, 1),
(49, 21, 2),
(53, 22, 2),
(52, 22, 1),
(54, 22, 3),
(55, 23, 1),
(56, 23, 2),
(57, 23, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `userdirecc`
--

CREATE TABLE `userdirecc` (
  `id_userdirecc` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_direcc` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `userdirecc`
--

INSERT INTO `userdirecc` (`id_userdirecc`, `id_user`, `id_direcc`) VALUES
(3, 2, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(35) DEFAULT NULL,
  `apellido` varchar(35) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `contrasena` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `correo`, `contrasena`) VALUES
(1, 'Alexis', 'Monterroza', 'xenia2998@gmail.com', '$2y$12$m/oFQxjPFNoIr33XksPyteA.k5QeR.RJmenFjsCtYxx7n6FGnwF2q'),
(2, 'Bryan ', 'Hernandez', '123@gmail.com', '$2y$12$wQ0plIujTyzmYRqJvCsA0.0SZ4xXaupKqHM.yr2PKjcNdUyWx6UnW');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `id_venta` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_direccion` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `fecha` varchar(11) DEFAULT NULL,
  `total` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `venta`
--

INSERT INTO `venta` (`id_venta`, `id_user`, `id_direccion`, `estado`, `fecha`, `total`) VALUES
(6, 2, 3, 'Pendiente', '12-06-2019', 80);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`id_detallventa`),
  ADD KEY `id_venta` (`id_venta`),
  ADD KEY `id_product` (`id_product`);

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mujer`
--
ALTER TABLE `mujer`
  ADD PRIMARY KEY (`id_mujer`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `prueba`
--
ALTER TABLE `prueba`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `talla`
--
ALTER TABLE `talla`
  ADD PRIMARY KEY (`id_talla`);

--
-- Indices de la tabla `tallamujer`
--
ALTER TABLE `tallamujer`
  ADD PRIMARY KEY (`id_talmujer`),
  ADD KEY `id_mujer` (`id_mujer`),
  ADD KEY `id_talla` (`id_talla`);

--
-- Indices de la tabla `tallaproduct`
--
ALTER TABLE `tallaproduct`
  ADD PRIMARY KEY (`id_tapro`),
  ADD KEY `id_producto` (`id_producto`),
  ADD KEY `id_talla` (`id_talla`);

--
-- Indices de la tabla `userdirecc`
--
ALTER TABLE `userdirecc`
  ADD PRIMARY KEY (`id_userdirecc`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_direcc` (`id_direcc`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`id_venta`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_direccion` (`id_direccion`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `id_detallventa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mujer`
--
ALTER TABLE `mujer`
  MODIFY `id_mujer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `prueba`
--
ALTER TABLE `prueba`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `talla`
--
ALTER TABLE `talla`
  MODIFY `id_talla` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tallamujer`
--
ALTER TABLE `tallamujer`
  MODIFY `id_talmujer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `tallaproduct`
--
ALTER TABLE `tallaproduct`
  MODIFY `id_tapro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `userdirecc`
--
ALTER TABLE `userdirecc`
  MODIFY `id_userdirecc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
