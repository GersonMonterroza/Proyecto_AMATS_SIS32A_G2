<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <link rel="icon" href="View/IMG/IMG2/z.ico">
    <title>Calzado Lili| |Inicio</title>
    <link rel="stylesheet" href="View/CSS/reset.css">
    <link rel="stylesheet" href="View/CSS/css_inicio.css">
    <link rel="stylesheet" href="View/CSS/font/flaticon.css">

    <link rel="stylesheet" href="View/Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="View/Alertify/css/alertify.css">
    <link rel="stylesheet" href="View/Alertify/css/themes/default.css">
    <script src="View/JavaScript/jquery-3.1.1.min.js"></script>
    <script src="View/Bootstrap/js/bootstrap.js"></script>
    <script src="View/Alertify/alertify.js"></script>
    
</head>
<body>
    
    <?php
        require("Controller/viewcontrol.php");
    ?>

</body>
</html>