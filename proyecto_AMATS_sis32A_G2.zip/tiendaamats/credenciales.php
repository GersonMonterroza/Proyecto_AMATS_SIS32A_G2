<?php
define("SERVIDOR","localhost:3306");
define("USUARIO","root");
define("CONTRA","");
define("BASEDATOS","tienda_online");
?>